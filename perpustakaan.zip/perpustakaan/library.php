<?php
class library
{
    private $books = [];

    public function addbook(ReferenceBook $book)
    {
        $this->books[] = $book;
    }
    public function caribookByISBN($isbn)
    {
        foreach ($this->books as $key => $book) {
            if ($book instanceof ReferenceBook && $book->getISBN() === $isbn) {
                return $this->books[$key];
            }
        }
        return false;
    }
    public function deletebook($isbn)
    {
        foreach ($this->books as $key => $book) {
            if ($book instanceof ReferenceBook && $book->getISBN() === $isbn) {
                unset($this->books[$key]);
                return true;
            }
        }
        return false;
    }
    public function getSemuabook()
    {
        return $this->books;
    }

    public function caribook($keyword)
    {
        $hasil = [];

        foreach ($this->books as $book) {
            if (stripos($book->getJudul(), $keyword) !== false || stripos($book->getPenulis(), $keyword) !== false) {
                $hasil[] = $book;
            }
        }

        return $hasil;
    }

    public function urutkanbook($kriteria)
    {
        $bookTerurut = $this->books;

        usort($bookTerurut, function ($a, $b) use ($kriteria) {
            if ($kriteria === 'penulis') {
                return strcmp($a->getPenulis(), $b->getPenulis());
            } elseif ($kriteria === 'tahun') {
                return $a->getTahunTerbit() - $b->getTahunTerbit();
            }
            return 0;
        });

        return $bookTerurut;
    }
    public function cekBatasPinjam($peminjam)
    {
        $peminjamCounter = 0;

        foreach ($this->books as $book) {
            if ($book->dipinjam()) {
                $peminjambook = $book->getPeminjam();
                if ($peminjambook === $peminjam) {
                    $peminjamCounter++;
                }
            }
        }

        if ($peminjamCounter >= 3) {
            echo "<script>alert('Anda telah mencapai batas peminjaman');</script>";
            return false;
        }
        return true;
    }

    public function saveKeSession()
    {
        $_SESSION['library'] = $this;
    }
}
