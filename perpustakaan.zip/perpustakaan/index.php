<?php
require_once "library.php";
require_once "book.php";
session_start();

if (!isset($_SESSION['library'])) {
    $_SESSION['library'] = new library();
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['addbook'])) {
        $isbn = $_POST['isbn'];
        $judul = $_POST['judul'];
        $penulis = $_POST['penulis'];
        $penerbit = $_POST['penerbit'];
        $tahun = $_POST['tahun'];

        $newBook = new ReferenceBook($judul, $penulis, $tahun, $isbn, $penerbit);
        $_SESSION['library']->addbook($newBook);
    }
    if (isset($_POST['deletebook'])) {

        if (isset($_POST['isbn'])) {

            $isbn = $_POST['isbn'];
            if (isset($_SESSION['library'])) {
                $_SESSION['library']->deletebook($isbn);
            }
        }
    }

    if (isset($_POST['pinjambook'])) {
        $isbn = $_POST['isbn'];
        $peminjam = $_POST['peminjam'];
        $date_kembali = $_POST['date'];

        if ($_SESSION['library']->cekBatasPinjam($peminjam)) {
            $book = $_SESSION['library']->caribookByISBN($isbn);

            if ($book) {
                $book->pinjambook($peminjam, $date_kembali);
                $_SESSION['library']->saveKeSession();
            }
        }
    }

    if (isset($_POST['kembalikanbuku'])) {
        $isbn = $_POST['isbn'];

        $book = $_SESSION['library']->caribookByISBN($isbn);

        if ($book) {
            $book->kembalikanbuku();
            $_SESSION['library']->saveKeSession();
        } else {
            echo "<script>alert('Tidak ada book yang dikembalikan');</script>";
        }
    }
}
?>

<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Perpustakaan Kampus</title>
    
    <link rel="stylesheet" href="style.css">

     <!-- Bootstrap CSS -->
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Bootstrap Icons CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">

    <!-- jQuery -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>


    <style>
        .card-book {
            width: 200px;
        }

        body {
            /* Background image */
            background-image: url('https://img.freepik.com/free-vector/blue-fluid-background_53876-114597.jpg?t=st=1714700797~exp=1714704397~hmac=b27955e5dbb9e033f756975e605e9ada3b530f05f4d00105894d7cda8c640a33&w=1060'); /* Ganti URL dengan URL gambar latar belakang Anda */
            background-size: cover; /* Untuk mengatur agar gambar latar belakang mengisi seluruh halaman */
            background-position: center; /* Untuk mengatur posisi gambar latar belakang ke tengah */
        }

    </style>
</head>

<body>
<nav class="navbar navbar-expand-lg navbar-dark bg-primary">
    <div class="container">
        <div class="d-flex align-items-center"> <!-- Container untuk Perpustakaan Kampus dan kolom pencarian -->
            <a class="navbar-brand me-3" href="#"> <!-- Menambahkan margin di kanan -->
                Perpustakaan Kampus
            </a>
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST" class="ml-auto">
                <div class="input-group flex-grow-1"> <!-- Menambahkan flex-grow-1 untuk memperluas kolom pencarian -->
                    <input type="text" class="form-control" placeholder="Pencarian" name="keyword" aria-label="Cari book" aria-describedby="button-addon2">
                    <button class="btn btn-outline-light" type="submit" id="button-addon2">Cari</button>
                </div>
            </form>
        </div>
    </div>
</nav>


    <div class="modal fade" id="modalPinjam" tabindex="-1" aria-labelledby="modalLabelPinjam" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="modalLabelPinjam">Pinjam book?</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
                    <div class="modal-body">
                        <input type="hidden" class="form-control" id="pinjamISBN" name="isbn" required>
                        <div class="mb-3">
                            <label for="modalPeminjam" class="form-label">Nama Peminjam</label>
                            <input type="text" class="form-control" name="peminjam" id="modalPeminjam" required>
                        </div>
                        <div class="input-group date mb-3" id="datepicker">
                            <input type="date" class="form-control" name="date" required>
                        </div>
                    </div>
                    <div class="modal-footer">-
                        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Tidak</button>
                        <button type="submit" name="pinjambook" class="btn btn-primary">Ya</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <div class="modal fade" id="modalHapus" tabindex="-1" aria-labelledby="modalLabelHapus" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="modalLabelHapus">Delete Book?</h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
                    <div class="modal-body">
                        <p>Apakah anda yakin ingin menghapus buku ini?</p>
                        <input type="hidden" name="isbn" id="hapusISBN" value="" />
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Tidak</button>
                        <button type="submit" name="deletebook" class="btn btn-primary">Ya</button>
                    </div>
                </form>
            </div>
        </div>
    </div >
    <div class="container">
        <div class="mx-auto px-5 my-3 d-flex justify-content-end align-items-end">
            <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
                <div class="mb-3">
                    <label for="sort" class="form-label">Sortir</label>
                    <div class="d-flex gap-2"><select class="form-select" aria-label="Sortir book" id="sort" name="sort">
                            <option selected value="penulis">Penulis</option>
                            <option value="tahun">Tahun Penerbit</option>
                        </select>
                        <button type="submit" name="apply_sort" class="btn btn-primary"><i class="bi bi-filter"></i>apply</button>
                    </div>
                </div>
            </form>
        </div>

       

            <div class="col-md-6">
                <div class="card my-3">
                    <div class="card-body">
            <h3>Daftar Buku</h3>
            <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['apply_sort'])) {
        $sortCriteria = $_POST['sort'];

        $sortedBooks = $_SESSION['library']->urutkanbook($sortCriteria);

        foreach ($sortedBooks as $book) {
            if (!$book->dipinjam()) {
                echo "<div class='list-group-item'>";
                echo "<div class='d-flex'>";
                echo "<div class='left text-start flex-grow-1'>";
                echo "<div class='card-body'>";
                echo "<h5 class='card-title'>" . $book->getJudul() . "</h5>";
                echo "<h6 class='card-subtitle mb-2 text-body-secondary'>" . $book->getPenulis() . " - " . $book->getTahunTerbit() . "</h6>";
                echo "<h6 class='card-subtitle mb-2 text-body-secondary'>" . $book->getPenerbit() . "</h6>";
                echo "</div>";
                echo "</div>";
                echo "<div class='right d-flex gap-2 align-items-center'>";
                echo "<a type='button' class='btn btn-primary btn-pinjam' name='pinjam' data-bs-toggle='modal' data-bs-target='#modalPinjam' data-isbn='" . $book->getISBN() . "'><i class='bi bi-bookmark-plus'></i> Pinjam</a>";
                echo "<a type='button' class='btn btn-danger btn-hapus' name='hapus' data-bs-toggle='modal' data-bs-target='#modalHapus' data-isbn='" . $book->getISBN() . "'><i class='bi bi-file-x'></i> Hapus</a>";
                echo "</div>";
                echo "</div>";
                echo "</div>";
            }
        }
    } elseif ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['keyword'])) {
        $keyword = $_POST['keyword'];
        $searchResults = $_SESSION['library']->caribook($keyword);
        if (sizeof($searchResults) > 0) {
            foreach ($searchResults as $book) {
                if (!$book->dipinjam()) {
                    echo "<div class='list-group-item'>";
                    echo "<div class='d-flex'>";
                    echo "<div class='left text-start flex-grow-1'>";
                    echo "<div class='card-body'>";
                    echo "<h5 class='card-title'>" . $book->getJudul() . "</h5>";
                    echo "<h6 class='card-subtitle mb-2 text-body-secondary'>" . $book->getPenulis() . " - " . $book->getTahunTerbit() . "</h6>";
                    echo "<h6 class='card-subtitle mb-2 text-body-secondary'>" . $book->getPenerbit() . "</h6>";
                    echo "</div>";
                    echo "</div>";
                    echo "<div class='right d-flex gap-2 align-items-center'>";
                    echo "<a type='button' class='btn btn-primary btn-pinjam' name='pinjam' data-bs-toggle='modal' data-bs-target='#modalPinjam' data-isbn='" . $book->getISBN() . "'><i class='bi bi-bookmark-plus'></i> Pinjam</a>";
                    echo "<a type='button' class='btn btn-danger btn-hapus' name='hapus' data-bs-toggle='modal' data-bs-target='#modalHapus' data-isbn='" . $book->getISBN() . "'><i class='bi bi-file-x'></i> Hapus</a>";
                    echo "</div>";
                    echo "</div>";
                    echo "</div>";
                }
            }
        } else {
            echo "<p>Tidak ada buku dengan judul dan penulis $keyword</p>";
        }
    } else {
        foreach ($_SESSION['library']->getSemuabook() as $book) {
            if (!$book->dipinjam()) {
                echo "<div class='list-group-item'>";
                echo "<div class='d-flex'>";
                echo "<div class='left text-start flex-grow-1'>";
                echo "<div class='card-body'>";
                echo "<h5 class='card-title'>" . $book->getJudul() . "</h5>";
                echo "<h6 class='card-subtitle mb-2 text-body-secondary'>" . $book->getPenulis() . " - " . $book->getTahunTerbit() . "</h6>";
                echo "<h6 class='card-subtitle mb-2 text-body-secondary'>" . $book->getPenerbit() . "</h6>";
                echo "</div>";
                echo "</div>";
                echo "<div class='right d-flex gap-2 align-items-center'>";
                echo "<a type='button' class='btn btn-primary btn-pinjam' name='pinjam' data-bs-toggle='modal' data-bs-target='#modalPinjam' data-isbn='" . $book->getISBN() . "'><i class='bi bi-bookmark-plus'></i> Pinjam</a>";
                echo "<a type='button' class='btn btn-danger btn-hapus' name='hapus' data-bs-toggle='modal' data-bs-target='#modalHapus' data-isbn='" . $book->getISBN() . "'><i class='bi bi-file-x'></i> Hapus</a>";
                echo "</div>";
                echo "</div>";
                echo "</div>";
            }
        }
    }
    ?>
</div>
        </div>
        
            <div class="col-md-6">
                <div class="card my-3">
                    <div class="card-body">
                        Tambahkan Buku
                    </div>
                    <div class="card-body">
                        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
                            <div class="mb-3">
                                <label for="inISBN" class="form-label">ISBN</label>
                                <input type="text" class="form-control" id="inISBN" name="isbn" required>
                            </div>
                            <div class="mb-3">
                                <label for="inJudul" class="form-label">Judul Buku</label>
                                <input type="text" class="form-control" id="inJudul" name="judul" required>
                            </div>
                            <div class="mb-3">
                                <label for="inPenulis" class="form-label">Penulis</label>
                                <input type="text" class="form-control" id="inPenulis" name="penulis" required>
                            </div>
                            <div class="mb-3">
                                <label for="inPenerbit" class="form-label">Penerbit</label>
                                <input type="text" class="form-control" id="inPenerbit" name="penerbit" required>
                            </div>
                            <div class="mb-3">
                                <label for="inTahun" class="form-label">Tahun Terbit</label>
                                <input type="number" min="1900" max="2099" step="1" class="form-control" id="inTahun" name="tahun" required>
                            </div>
                            <button type="submit" name="addbook" class="btn btn-primary"><i class="bi bi-plus">Tambahkan</i></button>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card my-3">
                    <div class="card-body">
                        Pengembalian Buku
                    </div>
                    <div class="card-body">
                        <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="POST">
                            <label for="kembaliISBN">Buku</label>
                            <select class="form-select mb-3" aria-label="Default select example" name="isbn" id="kembaliISBN" required>
                                <?php
                                $counter = 0;

                                foreach ($_SESSION['library']->getSemuabook() as $book) {
                                    if ($book->dipinjam()) {
                                        echo "<option value='" . $book->getISBN() . "'>" . $book->getJudul() . "</option>";
                                    } else {
                                        $counter++;
                                    }
                                }
                                if ($counter === sizeof($_SESSION['library']->getSemuabook())) {
                                    echo "<option value='kosong'>Tidak ada buku yang sedang dipinjam</option>";
                                } ?>
                            </select>
                            <button type="submit" name="kembalikanbuku" class="btn btn-primary"><i class="bi bi-save"> Kembalikan Buku</i></button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
    
    <script>
        $(document).on("click", ".btn-hapus", function() {
            var isbn = $(this).data('isbn');
            $(".modal-body #hapusISBN").val(isbn);
        });
        $(document).on("click", ".btn-pinjam", function() {
            var isbn = $(this).data('isbn');
            $(".modal-body #pinjamISBN").val(isbn);
        });     
    </script>
</body>

</html>